module com.mycompany.duck_hunt {
    requires javafx.controls;
    exports com.mycompany.duck_hunt;
}
