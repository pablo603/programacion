package com.mycompany.duck_hunt;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;



public class App extends Application {
    int Contador = 0;
    double ballCenterX =  Math.random()*401 ; // 10 int 
    double ballCenterY =  Math.random()*401 ; // 30 int 
    int ballCurrentSpeedX = 3;
    int dirr_circleball3_x = 3;
    int dirr_circleball1_x = 3;
    int dirr_circleball2_x = 3;
    int ballCurrentSpeedY = 3;
    final int SCENE_TAM_X = 400;
    final int SCENE_TAM_Y = 400;
    double X_diferencia = 0; 
    double Y_diferencia = 0;
    Pane paneRoot = new Pane();
    Circle circleBall = new Circle(ballCenterX,ballCenterY,7);
    Circle circleBall1 = new Circle(ballCenterX,ballCenterY,7);
    Circle circleBall2 = new Circle(ballCenterX,ballCenterY,7);
    
    @Override
    public void start(Stage stage) {
        // Panel principal que contendrá los elementos de la pantalla
  
        var scene = new Scene(paneRoot, SCENE_TAM_X, SCENE_TAM_Y);        
        stage.setScene(scene);
        stage.show();
        
        // Cargar la imagen crear objeto ImageView
        Image img = new Image(getClass().getResourceAsStream("/images/duck_hunt1.jpg"));
        ImageView imgView = new ImageView(img);
        
        // Añadir el ImageView al panel principal de la pantalla
        paneRoot.getChildren().add(imgView);
        
        // Texto
        Text t = new Text(10, 50, "Contador : ");
        t.setFont(new Font(20));
        paneRoot.getChildren().add(t);
        // Creacion de la bola 
       
        circleBall.setFill(Color.RED);
        paneRoot.getChildren().add(circleBall);
        // Moviento bola 
//        Timeline animationBall = new Timeline(
//                new KeyFrame(Duration.seconds(0.017), (ActionEvent ae) -> {
//                    circleBall.setCenterX(ballCenterX);
//                    ballCenterX += ballCurrentSpeedX ;
//                    if (ballCenterX >= SCENE_TAM_X) {
//                        ballCurrentSpeedX = -3;
//                    }
//                    if (ballCenterX <=0) {
//                        ballCurrentSpeedX = 3;
//                    }
//                    if (ballCenterY >= SCENE_TAM_Y){
//                    ballCurrentSpeedY = -3;
//                    }
//                    if (ballCenterY <= 0 ) {
//                    ballCurrentSpeedY = 3;
//                    }
//                }  
//        ));
//        animationBall.setCycleCount(Timeline.INDEFINITE);
//        animationBall.play();
        crear_animacion(circleBall , 1);
        //Dibujo muñeco
        Polyline polyline = new Polyline();
        paneRoot.getChildren().add(polyline);
        polyline.getPoints().addAll(new Double[]{
        0.0, 0.0,
        20.0, 10.0,
        10.0, 20.0 });
        // detectar raton pulsado
        scene.setOnMousePressed((MouseEvent mouseEvent) -> {
            // Insertar aquí el código a ejecutar cuando se pulse el ratón
            System.out.println("Mouse pressed X : Y - " +
                    mouseEvent.getX() + " : " + mouseEvent.getY());
            if (Contador == 0 ) {
             
            X_diferencia = Math.abs( mouseEvent.getX() - circleBall.getCenterX()) ;
            Y_diferencia = Math.abs(mouseEvent.getY() - circleBall.getCenterY());
           if (X_diferencia  < 10 && Y_diferencia < 10);
//           paneRoot.getChildren().remove(circleBall);
             Contador += 1;
                crear_bola(Contador);
          }else if (Contador == 1){
           
          }
        });
            
    }
    
    public void crear_bola (int contador){
      
        if ( contador == 1 ) {
           circleBall1.setFill(Color.YELLOW);
        paneRoot.getChildren().add(circleBall1);
        circleBall1.setCenterY(30);
        // Moviento bola 
            crear_animacion(circleBall1,2);
        }       
    }
    public void crear_animacion (Circle pelota, int num_bola){
        
        Timeline animationBall = new Timeline(
                new KeyFrame(Duration.seconds(0.017), (ActionEvent ae) -> {
                   // comprueba si la pelota esta en el final de la pantalla
                   // si es asi cambiamos la dirrecion (negativo positivo)
                    if (pelota.getCenterX() >= SCENE_TAM_X) {
                        switch (num_bola) {
                            case 1:
                                dirr_circleball1_x = -3;
                                break;
                            case 2:
                                dirr_circleball2_x = -3;
                                break; 
                            default:
                                dirr_circleball3_x = -3;
                                break;
                        }
                    }
                    //comprobamos si esta en el inicio de la pantalla
                    if (pelota.getCenterX() <= 0) { 
                        switch (num_bola) {
                            case 1:
                                dirr_circleball1_x = 3;
                                break;
                            case 2:
                                dirr_circleball2_x = 3;
                                break; 
                            default:
                                dirr_circleball3_x = 3;
                                break;
                        }
                    }
                    //aumentamos la posiciopn de cada pelota, cojiendo su posicion
                    //actual y le sumamos 3 o le restamos 3
                    switch (num_bola) {
                    case 1:
                        pelota.setCenterX(pelota.getCenterX() + dirr_circleball1_x);
                        break;
                        case 2:
                        pelota.setCenterX(pelota.getCenterX() + dirr_circleball2_x);
                        break; 
                        default:
                        pelota.setCenterX(pelota.getCenterX() + dirr_circleball3_x);
                        break;
                    }
                    //pendiente 
//                    if (ballCenterY >= SCENE_TAM_Y){
//                    ballCurrentSpeedY = -3;
//                    }
//                    if (ballCenterY <= 0 ) {
//                    ballCurrentSpeedY = 3;
//                    }
                }  
        ));
        animationBall.setCycleCount(Timeline.INDEFINITE);
        animationBall.play(); 
       
    }
    
    public static void main(String[] args) {
        launch();
    }

}